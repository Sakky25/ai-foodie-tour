# Workflow Plan for AI Foodie Tour

## Inputs
- List of cities

## Workflow Modules

### 1. Weather API (OpenWeatherMap)
- URL: https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}
- Output: weather condition

### 2. Indoor/Outdoor Dining
- LLM prompt based on weather condition

### 3. Local Dishes
- Prompt: "What are 3 iconic dishes someone should try in {city}?"

### 4. Restaurant Finder
- Google Places or Yelp API to get restaurants by dish

### 5. Foodie Tour Creator
- Prompt: "Write a delightful one-day foodie tour for breakfast, lunch, and dinner."

### 6. Final Output
- Summary of weather, dishes, restaurants, and foodie narrative
